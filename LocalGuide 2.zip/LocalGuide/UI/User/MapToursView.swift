import SwiftUI
import MapKit
import CoreLocation
import UIKit

/// Map screen showing the user's location plus nearby Tours and Experiences.
struct MapToursView: View {
    @State private var tours: [Tour] = []
    @State private var experiences: [Experience] = []
    @State private var isLoading = false

    @StateObject private var directory = ProfileDirectory()
    @StateObject private var locationManager = LocationManager()

    // ✅ Start with .none so the map does NOT keep snapping to the user as pins reload
    @State private var userTrackingMode: MKUserTrackingMode = .none
    @State private var didCenterOnUser = false

    @State private var selectedTour: Tour?
    @State private var selectedExperience: Experience?
    @State private var currentRegion: MKCoordinateRegion?
    @State private var regionDebounceTask: Task<Void, Never>?
    @State private var lastLoadedRegionKey: String = ""
    
    private func regionKey(_ r: MKCoordinateRegion) -> String {
        // coarse key so we don’t reload for tiny pans
        let lat = (r.center.latitude * 100).rounded() / 100
        let lon = (r.center.longitude * 100).rounded() / 100
        let spanLat = (r.span.latitudeDelta * 100).rounded() / 100
        let spanLon = (r.span.longitudeDelta * 100).rounded() / 100
        return "\(lat),\(lon),\(spanLat),\(spanLon)"
    }

    private func bounds(for r: MKCoordinateRegion) -> (minLat: Double, maxLat: Double, minLon: Double, maxLon: Double) {
        let minLat = r.center.latitude - r.span.latitudeDelta / 2
        let maxLat = r.center.latitude + r.span.latitudeDelta / 2
        let minLon = r.center.longitude - r.span.longitudeDelta / 2
        let maxLon = r.center.longitude + r.span.longitudeDelta / 2
        return (minLat, maxLat, minLon, maxLon)
    }

    /// Briefly enables follow mode to center on the user's location, then turns it off to prevent jumping.
    private func recenterOnce() {
        userTrackingMode = .followWithHeading
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
            userTrackingMode = .none
        }
    }

    private var pins: [ListingsMapView.ListingPin] {
        let tourPins: [ListingsMapView.ListingPin] = tours.compactMap { (t) -> ListingsMapView.ListingPin? in
            guard let lat = t.latitude, let lon = t.longitude else { return nil }
            return ListingsMapView.ListingPin(
                id: "tour-\(t.id)",
                kind: .tour,
                title: t.title,
                subtitle: t.city,
                coordinate: CLLocationCoordinate2D(latitude: lat, longitude: lon),
                category: t.category ?? "Tour"
            )
        }

        let expPins: [ListingsMapView.ListingPin] = experiences.compactMap { (e) -> ListingsMapView.ListingPin? in
            guard let lat = e.latitude, let lon = e.longitude else { return nil }
            return ListingsMapView.ListingPin(
                id: "exp-\(e.id)",
                kind: .experience,
                title: e.title,
                subtitle: e.city,
                coordinate: CLLocationCoordinate2D(latitude: lat, longitude: lon),
                category: e.category ?? "Experience"
            )
        }

        let allPins = tourPins + expPins

        // If we have location, show nearby items only.
        guard let userLoc = locationManager.lastLocation else {
            return allPins
        }

        let maxKm: Double = 50
        func isNearby(_ c: CLLocationCoordinate2D) -> Bool {
            let d = userLoc.distance(from: CLLocation(latitude: c.latitude, longitude: c.longitude))
            return (d / 1000.0) <= maxKm
        }

        return allPins.filter { isNearby($0.coordinate) }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                ListingsMapView(
                    userTrackingMode: $userTrackingMode, pins: pins,
                    onSelect: { pin in
                        switch pin.kind {
                        case .tour:
                            let id = pin.id.replacingOccurrences(of: "tour-", with: "")
                            selectedTour = tours.first(where: { $0.id == id })
                        case .experience:
                            let id = pin.id.replacingOccurrences(of: "exp-", with: "")
                            selectedExperience = experiences.first(where: { $0.id == id })
                        }
                    },
                    onRegionChange: { region in
                        currentRegion = region
                        regionDebounceTask?.cancel()
                        regionDebounceTask = Task{
                            try? await Task.sleep(nanoseconds: 450_000_000)
                            guard !Task.isCancelled else { return }
                            await loadForVisibleRegion(region)
                        }
                    }).ignoresSafeArea()
                
                // Re-center button (does NOT keep following after snap)
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Button {
                            recenterOnce()
                        } label: {
                            Image(systemName: "location.fill")
                                .font(.headline)
                                .padding(12)
                                .background(.ultraThinMaterial)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Lx.gold.opacity(0.25), lineWidth: 1))
                        }
                        .padding(.trailing, 16)
                        .padding(.bottom, 24)
                    }
                }
                
                if isLoading {
                    //LuxuryCard { ProgressView("Loading…").tint(Lx.gold) }
                    //   .padding()
                }
                
                // Permission / failure hint
                if locationManager.authorization == .denied || locationManager.authorization == .restricted {
                    VStack {
                        Spacer()
                        LuxuryCard {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Location is off")
                                    .font(.headline)
                                Text("Enable location to see your position and nearby tours/experiences on the map.")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                                Button {
                                    if let url = URL(string: UIApplication.openSettingsURLString) {
                                        UIApplication.shared.open(url)
                                    }
                                } label: {
                                    Text("Open Settings")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(Lx.gold)
                            }
                        }
                        .padding()
                    }
                } else if locationManager.didFail {
                    VStack {
                        Spacer()
                        LuxuryCard {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Can't get your location")
                                    .font(.headline)
                                Text("If you're on the Simulator, set a simulated location in Xcode (Debug > Location).")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding()
                    }
                }
            }
            .navigationTitle("Map")
            .task {
                locationManager.requestPermission()
                await load()
            }
            
            // ✅ Center only once, when location becomes available the first time
            .onChange(of: locationManager.lastLocation) { newLoc in
                guard newLoc != nil else { return }
                if !didCenterOnUser {
                    didCenterOnUser = true
                    // small delay so map renders before snapping
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                        recenterOnce()
                    }
                }
            }
            
            .fullScreenCover(item: $selectedTour) { t in
                NavigationStack { TourDetailsView(tour: t) }
            }
            .fullScreenCover(item: $selectedExperience) { e in
                NavigationStack { ExperienceDetailsView(experience: e) }
            }
        }
    }
    private func load() async {
        isLoading = true
        defer { isLoading = false }
        do {
            tours = try await FirestoreService.shared.getTours(city: nil)
            experiences = try await FirestoreService.shared.getExperiences(city: nil)

            for t in tours { await directory.loadGuideIfNeeded(t.guideId) }
            for e in experiences { await directory.loadHostIfNeeded(e.hostId) }
        } catch {
            tours = []
            experiences = []
        }
    }
    private func loadForVisibleRegion(_ region: MKCoordinateRegion) async {
        // Avoid reloading same region repeatedly
        let key = regionKey(region)
        if key == lastLoadedRegionKey { return }
        lastLoadedRegionKey = key

        isLoading = true
        defer { isLoading = false }

        let b = bounds(for: region)

        do {
            // ✅ Query server by latitude range; filter longitude client-side.
            // These methods need to exist in FirestoreService (see section 4).
            let tourCandidates = try await FirestoreService.shared.getToursByLatitudeRange(
                minLat: b.minLat, maxLat: b.maxLat, limit: 400
            )
            let expCandidates = try await FirestoreService.shared.getExperiencesByLatitudeRange(
                minLat: b.minLat, maxLat: b.maxLat, limit: 400
            )

            tours = tourCandidates.filter { t in
                guard let lat = t.latitude, let lon = t.longitude else { return false }
                return lat >= b.minLat && lat <= b.maxLat && lon >= b.minLon && lon <= b.maxLon
            }

            experiences = expCandidates.filter { e in
                guard let lat = e.latitude, let lon = e.longitude else { return false }
                return lat >= b.minLat && lat <= b.maxLat && lon >= b.minLon && lon <= b.maxLon
            }

        } catch {
            // leave old pins; don’t wipe UI on transient errors
            print("Map region load failed:", error.localizedDescription)
        }
    }
}
