import SwiftUI
import MapKit
import CoreLocation
import UIKit

/// MKMapView wrapper that supports clustering, category-colored pins, and smooth user tracking.
/// Optimizations:
/// - Debounced regionDidChange notifications (single callback)
/// - Diff-based annotation updates (avoid remove-all/add-all)
/// - Stable clustering + reduced expensive redraws
struct ListingsMapView: UIViewRepresentable {

    // MARK: - Pin Model

    struct ListingPin: Identifiable, Hashable {
        enum Kind: String { case tour, experience }

        let id: String
        let kind: Kind
        let title: String
        let subtitle: String?
        let coordinate: CLLocationCoordinate2D
        let category: String?

        // Hash/equality by id for fast diffing
        static func == (lhs: ListingPin, rhs: ListingPin) -> Bool { lhs.id == rhs.id }
        func hash(into hasher: inout Hasher) { hasher.combine(id) }
    }

    // MARK: - API

    @Binding var userTrackingMode: MKUserTrackingMode
    var pins: [ListingPin]
    var onSelect: (ListingPin) -> Void
    /// Called when the visible map region changes (pan/zoom or user tracking).
    var onRegionChange: ((MKCoordinateRegion) -> Void)? = nil

    // MARK: - UIViewRepresentable

    func makeUIView(context: Context) -> MKMapView {
        let map = MKMapView(frame: .zero)
        map.delegate = context.coordinator

        map.showsUserLocation = true
        map.pointOfInterestFilter = .excludingAll
        map.showsCompass = true
        map.showsScale = true
        map.isRotateEnabled = true
        map.isPitchEnabled = true

        // Prefer smoother follow behavior.
        map.setUserTrackingMode(userTrackingMode, animated: false)

        // Register reusable views
        map.register(MKMarkerAnnotationView.self, forAnnotationViewWithReuseIdentifier: "listing")
        map.register(MKMarkerAnnotationView.self, forAnnotationViewWithReuseIdentifier: "cluster")

        return map
    }

    func updateUIView(_ uiView: MKMapView, context: Context) {
        // Tracking mode updates
        if uiView.userTrackingMode != userTrackingMode {
            uiView.setUserTrackingMode(userTrackingMode, animated: true)
        }

        // ✅ Diff-based annotation updates
        context.coordinator.applyPins(pins, on: uiView)
    }

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    // MARK: - Coordinator

    final class Coordinator: NSObject, MKMapViewDelegate {
        let parent: ListingsMapView

        // Debounce region changes
        private var pendingRegionWorkItem: DispatchWorkItem?
        private var lastReportedRegionCenter: CLLocationCoordinate2D?
        private var lastReportedSpan: MKCoordinateSpan?

        // Annotation cache for diffing
        private var annotationsById: [String: ListingAnnotation] = [:]

        init(_ parent: ListingsMapView) {
            self.parent = parent
        }

        // MARK: - Pin Diff Apply

        func applyPins(_ newPins: [ListingPin], on mapView: MKMapView) {
            // Build sets
            let newIds = Set(newPins.map { $0.id })
            let oldIds = Set(annotationsById.keys)

            // Remove missing
            let toRemove = oldIds.subtracting(newIds)
            if !toRemove.isEmpty {
                let removedAnns: [ListingAnnotation] = toRemove.compactMap { annotationsById[$0] }
                removedAnns.forEach { annotationsById.removeValue(forKey: $0.pin.id) }
                mapView.removeAnnotations(removedAnns)
            }

            // Add new
            let toAdd = newIds.subtracting(oldIds)
            if !toAdd.isEmpty {
                let addPins = newPins.filter { toAdd.contains($0.id) }
                let addAnns = addPins.map { ListingAnnotation(pin: $0) }
                for ann in addAnns { annotationsById[ann.pin.id] = ann }
                mapView.addAnnotations(addAnns)
            }

            // Update changed coordinates/title/subtitle/category for existing annotations
            // (MapKit doesn’t love lots of updates; keep it minimal)
            for pin in newPins {
                guard let ann = annotationsById[pin.id] else { continue }
                if ann.pin != pin {
                    ann.update(with: pin)
                }
            }
        }

        // MARK: - Selection

        func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
            guard let ann = view.annotation as? ListingAnnotation else { return }
            parent.onSelect(ann.pin)
        }

        // MARK: - Region change (debounced, single callback)

        func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
            pendingRegionWorkItem?.cancel()

            let region = mapView.region
            let center = region.center
            let span = region.span

            // Avoid re-sending essentially identical updates.
            let isSameCenter: Bool
            if let last = lastReportedRegionCenter {
                let dLat = abs(last.latitude - center.latitude)
                let dLon = abs(last.longitude - center.longitude)
                isSameCenter = dLat < 0.001 && dLon < 0.001
            } else {
                isSameCenter = false
            }

            let isSameSpan: Bool
            if let lastSpan = lastReportedSpan {
                isSameSpan =
                    abs(lastSpan.latitudeDelta - span.latitudeDelta) < 0.001 &&
                    abs(lastSpan.longitudeDelta - span.longitudeDelta) < 0.001
            } else {
                isSameSpan = false
            }

            if isSameCenter && isSameSpan { return }

            let work = DispatchWorkItem { [weak self] in
                guard let self else { return }
                self.lastReportedRegionCenter = center
                self.lastReportedSpan = span
                self.parent.onRegionChange?(region)
            }

            pendingRegionWorkItem = work
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45, execute: work)
        }

        // MARK: - Annotation views (clustering optimized)

        func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
            if annotation is MKUserLocation { return nil }

            if let cluster = annotation as? MKClusterAnnotation {
                let v = mapView.dequeueReusableAnnotationView(withIdentifier: "cluster", for: cluster) as! MKMarkerAnnotationView
                v.annotation = cluster

                // ✅ Cluster optimization: consistent appearance, high priority
                v.markerTintColor = UIColor.systemGray
                v.glyphText = "\(cluster.memberAnnotations.count)"
                v.displayPriority = .required
                v.canShowCallout = false

                return v
            }

            guard let ann = annotation as? ListingAnnotation else { return nil }

            let v = mapView.dequeueReusableAnnotationView(withIdentifier: "listing", for: ann) as! MKMarkerAnnotationView
            v.annotation = ann

            // ✅ Stable clustering identifier
            v.clusteringIdentifier = "listing"

            // ✅ Performance: avoid callout heavy UI; still allow tap selection
            v.canShowCallout = true
            v.displayPriority = .defaultHigh

            // Category-colored pins.
            v.markerTintColor = UIColor(color(for: ann.pin.category, kind: ann.pin.kind))
            v.glyphImage = UIImage(systemName: ann.pin.kind == .tour ? "figure.walk" : "sparkles")

            return v
        }

        private func color(for category: String?, kind: ListingPin.Kind) -> Color {
            let c = (category ?? "").trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            if c.contains("food") || c.contains("culinary") { return .orange }
            if c.contains("hike") || c.contains("outdoor") || c.contains("nature") { return .green }
            if c.contains("museum") || c.contains("culture") || c.contains("history") { return .blue }
            if c.contains("night") || c.contains("party") { return .purple }
            if c.contains("wellness") || c.contains("spa") { return .pink }
            return kind == .tour ? .yellow : .teal
        }
    }
}

// MARK: - Annotation class (mutable update)

final class ListingAnnotation: NSObject, MKAnnotation {
    private(set) var pin: ListingsMapView.ListingPin

    init(pin: ListingsMapView.ListingPin) {
        self.pin = pin
        super.init()
    }

    // MKAnnotation conformance
    var coordinate: CLLocationCoordinate2D { pin.coordinate }
    var title: String? { pin.title }
    var subtitle: String? { pin.subtitle }

    // Update pin values without replacing annotation instance (keeps clustering stable)
    func update(with newPin: ListingsMapView.ListingPin) {
        // Coordinate updates must be KVO-compliant for MapKit to animate properly
        willChangeValue(forKey: "coordinate")
        pin = newPin
        didChangeValue(forKey: "coordinate")
    }
}
