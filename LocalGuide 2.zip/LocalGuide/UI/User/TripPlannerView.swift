import SwiftUI

/// AI Trip Designer entry screen for travelers.
/// Contains a short description + CTA that opens the planner form.
struct TripPlannerView: View {
    @EnvironmentObject var appState: AppState
    @State private var showCreateForm = false
    @State private var plans: [TripPlan] = []
    @State private var isLoading = false
    @State private var planToDelete: TripPlan?

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()

                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("AI Trip Planner")
                            .font(.largeTitle.bold())
                            .foregroundStyle(.white)
                            .padding(.top, 8)

                        LuxuryCard {
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Create an amazing trip with AI")
                                    .font(.headline)
                                    .foregroundStyle(.white)
                                Text("Tell us where you're going and what you love — we'll build a day-by-day itinerary in seconds.")
                                    .font(.subheadline)
                                    .foregroundStyle(.white.opacity(0.75))
                                    .frame(maxWidth: .infinity, alignment: .leading)

                                Button {
                                    Haptics.medium()
                                    showCreateForm = true
                                } label: {
                                    Text("Create trip plan")
                                }
                                .buttonStyle(LuxuryPrimaryButtonStyle())
                            }
                        }

                        // Show existing plans (most recent first)
                        if isLoading {
                            ProgressView().tint(Lx.gold)
                        } else if !plans.isEmpty {
                            LuxuryCard {
                                VStack(alignment: .leading, spacing: 10) {
                                    Text("Your trip plans")
                                        .font(.headline)
                                        .foregroundStyle(.white)

                                    Divider().opacity(0.15)

                                    ForEach(plans) { tp in
                                        HStack(alignment: .top, spacing: 10) {
                                            NavigationLink {
                                                TripPlanDetailView(tripPlan: tp)
                                            } label: {
                                                VStack(alignment: .leading, spacing: 4) {
                                                    Text(tp.planTitleFallback)
                                                        .font(.subheadline.weight(.semibold))
                                                        .foregroundStyle(.white)
                                                        .lineLimit(1)
                                                    Text("\(tp.city), \(tp.country)")
                                                        .font(.caption)
                                                        .foregroundStyle(.white.opacity(0.7))
                                                    Text("\(tp.startDateISO) → \(tp.endDateISO)")
                                                        .font(.caption2)
                                                        .foregroundStyle(.white.opacity(0.6))
                                                }
                                            }
                                            .buttonStyle(.plain)

                                            Spacer(minLength: 0)

                                            Button {
                                                Haptics.light()
                                                planToDelete = tp
                                            } label: {
                                                Image(systemName: "minus.circle")
                                                    .font(.title3)
                                                    .foregroundStyle(.white.opacity(0.35))
                                            }
                                            .buttonStyle(.plain)
                                            .accessibilityLabel("Delete trip plan")
                                        }

                                        if tp.id != plans.last?.id {
                                            Divider().opacity(0.12)
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(minLength: 12)
                    }
                    .padding(18)
                }
            }
            .navigationTitle("Trip Planner")
            .navigationBarTitleDisplayMode(.inline)
            .navigationDestination(isPresented: $showCreateForm) {
                TripPlannerFormView()
            }
            .task { await refreshPlans() }
            .onAppear { Task { await refreshPlans() } }
            .onChange(of: showCreateForm) { presenting in
                // When returning from the create form, refresh the list so the newly
                // created plan shows up immediately.
                if !presenting {
                    Task { await refreshPlans() }
                }
            }
            .confirmationDialog(
                "Delete this trip plan?",
                isPresented: Binding(get: { planToDelete != nil }, set: { if !$0 { planToDelete = nil } }),
                titleVisibility: .visible
            ) {
                Button("Delete", role: .destructive) {
                    guard let tp = planToDelete else { return }
                    Task { await delete(tp) }
                }
                Button("Cancel", role: .cancel) { planToDelete = nil }
            }
        }
    }

    private func delete(_ tp: TripPlan) async {
        do {
            try await FirestoreService.shared.deleteTripPlan(tripPlanId: tp.id)
            plans.removeAll { $0.id == tp.id }
        } catch {
            // Silent fail in UI; keep list unchanged.
        }
        planToDelete = nil
    }

    private func refreshPlans() async {
        guard let uid = appState.session.firebaseUser?.uid else { return }
        isLoading = true
        defer { isLoading = false }
        do {
            plans = try await FirestoreService.shared.listTripPlansForUser(uid: uid, limit: 20)
        } catch {
            plans = []
        }
    }
}

/// The actual AI Trip Designer form and results.
private struct TripPlannerFormView: View {
    @EnvironmentObject var appState: AppState

    @StateObject private var locationManager = LocationManager()

    @State private var country = "Romania"
    @State private var city = "Bucharest"
    @State private var showDestinationPicker = false
    @State private var startDate = Date()
    @State private var endDate = Calendar.current.date(byAdding: .day, value: 2, to: Date()) ?? Date()
    @State private var interestsText = "food, history, culture"
    @State private var budgetPerDayText = ""
    @State private var pace = "balanced"
    @State private var groupSize = 2

    @State private var isLoading = false
    @State private var errorText: String?
    @State private var plan: [String: Any]?
    @State private var tripPlanId: String?

    // Present the newly created plan immediately so itinerary listing cards show without reopening.
    @State private var createdTripPlan: TripPlan?

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    LuxuryCard {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Trip details")
                                .font(.title3.bold())
                                .foregroundStyle(.white)

                            Divider().opacity(0.15)

                            Button {
                                Haptics.light()
                                showDestinationPicker = true
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Destination")
                                            .font(.caption.weight(.semibold))
                                            .foregroundStyle(.secondary)
                                        Text("\(city), \(country)")
                                            .foregroundStyle(.white)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                        .foregroundStyle(.white.opacity(0.65))
                                }
                                .padding(.vertical, 8)
                            }
                            .buttonStyle(.plain)

                            DatePicker("Start", selection: $startDate, displayedComponents: [.date])
                                .datePickerStyle(.compact)
                            DatePicker("End", selection: $endDate, displayedComponents: [.date])
                                .datePickerStyle(.compact)

                            TextField("Interests (comma separated)", text: $interestsText)
                                .textFieldStyle(LuxuryTextFieldStyle())

                            TextField("Budget / day (optional)", text: $budgetPerDayText)
                                .keyboardType(.decimalPad)
                                .textFieldStyle(LuxuryTextFieldStyle())

                            Picker("Pace", selection: $pace) {
                                Text("Relaxed").tag("relaxed")
                                Text("Balanced").tag("balanced")
                                Text("Fast").tag("fast")
                            }
                            .pickerStyle(.segmented)

                            Stepper("Group size: \(groupSize)", value: $groupSize, in: 1...12)

                            Button {
                                Haptics.medium()
                                Task { await generate() }
                            } label: {
                                Text("Generate plan")
                            }
                            .buttonStyle(LuxuryPrimaryButtonStyle())
                        }
                    }

                    if let errorText {
                        LuxuryCard {
                            Text(errorText)
                                .foregroundStyle(.red)
                        }
                    }

                    if let plan {
                        TripPlanResultsView(plan: plan)
                    }

                    // Helpful identifier for debugging / support.
                    if let tripPlanId {
                        Text("Plan ID: \(tripPlanId)")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.6))
                            .padding(.horizontal, 4)
                    }
                }
                .padding(18)
            }

            if isLoading {
                VStack(spacing: 10) {
                    ProgressView().tint(Lx.gold)
                    Text("Generating...")
                        .foregroundStyle(.white.opacity(0.8))
                }
                .padding(18)
                .background(.thinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 16))
            }
        }
        .navigationTitle("Create plan")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showDestinationPicker) {
            DestinationPickerView(selectedCity: $city, selectedCountry: $country)
        }
        .onAppear {
            // Used only to improve recommendations (distance + nearby matching).
            locationManager.requestPermission()
        }
        .fullScreenCover(item: $createdTripPlan) { tp in
            DismissableSheet {
                TripPlanDetailView(tripPlan: tp)
            }
        }
    }

    private func generate() async {
        errorText = nil
        isLoading = true
        defer { isLoading = false }

        do {
            let interests = interestsText
                .split(separator: ",")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }

            let budget = Double(budgetPerDayText.replacingOccurrences(of: ",", with: "."))

            // Fetch in-app listings for the destination. The AI will be constrained to use ONLY these.
            // Keep the catalog compact: include only the fields the backend prompt uses.
            let cityTrim = city.trimmingCharacters(in: .whitespacesAndNewlines)
            let tours = try await FirestoreService.shared.getTours(city: cityTrim.isEmpty ? nil : cityTrim)
            let exps = try await FirestoreService.shared.getExperiences(city: cityTrim.isEmpty ? nil : cityTrim)

            func tourDict(_ t: Tour) -> [String: Any] {
                [
                    "id": t.id,
                    "title": t.title,
                    "category": t.category as Any,
                    "price": t.price,
                    "durationMinutes": t.durationMinutes,
                    "ratingAvg": t.ratingAvg as Any,
                    "ratingCount": t.ratingCount as Any,
                    "instantBook": t.instantBook as Any,
                ]
            }
            func expDict(_ e: Experience) -> [String: Any] {
                [
                    "id": e.id,
                    "title": e.title,
                    "category": e.category as Any,
                    "price": e.price,
                    "durationMinutes": e.durationMinutes,
                    "ratingAvg": e.ratingAvg as Any,
                    "ratingCount": e.ratingCount as Any,
                    "instantBook": e.instantBook as Any,
                ]
            }
            let catalog: [String: Any] = [
                "tours": tours.map(tourDict),
                "experiences": exps.map(expDict),
            ]

            let code = appState.settings.languageCode
            let res = try await TripPlannerService.shared.generateTripPlan(
                country: country,
                city: city,
                startDate: startDate,
                endDate: endDate,
                interests: interests,
                budgetPerDay: budget,
                pace: pace,
                groupSize: groupSize,
                catalog: catalog,
                languageCode: code
            )
            self.tripPlanId = res.tripPlanId
            self.plan = res.plan

            // Present the full trip plan details immediately so linked listing cards are visible
            // without requiring the user to reopen the plan from the list.
            if let uid = appState.session.firebaseUser?.uid {
                func toAnyCodable(_ v: Any) -> AnyCodable {
                    if let a = v as? [Any] {
                        return AnyCodable(a.map { toAnyCodable($0) })
                    }
                    if let d = v as? [String: Any] {
                        var out: [String: AnyCodable] = [:]
                        for (k, val) in d { out[k] = toAnyCodable(val) }
                        return AnyCodable(out)
                    }
                    return AnyCodable(v)
                }

                var planCodable: [String: AnyCodable] = [:]
                for (k, v) in res.plan { planCodable[k] = toAnyCodable(v) }

                let tp = TripPlan(
                    id: res.tripPlanId,
                    uid: uid,
                    country: country,
                    city: city,
                    startDateISO: startDate.isoDateOnlyString,
                    endDateISO: endDate.isoDateOnlyString,
                    interests: interests,
                    budgetPerDay: budget,
                    pace: pace,
                    groupSize: groupSize,
                    languageCode: code,
                    plan: planCodable,
                    recommendedTourIds: nil,
                    recommendedExperienceIds: nil,
                    createdAt: Date()
                )

                self.createdTripPlan = tp
            }

            // The backend already built the itinerary using only in-app listings via the catalog.
        } catch {
            self.errorText = error.localizedDescription
        }
    }

    private func linkInAppRecommendations(tripPlanId: String, inputs: TripRecommendationEngine.Inputs) async {
        do {
            // Fetch active listings in the same destination.
            let tours = try await FirestoreService.shared.getTours(city: inputs.city)
            let exps = try await FirestoreService.shared.getExperiences(city: inputs.city)

            let rec = await TripRecommendationEngine.shared.recommend(inputs: inputs, tours: tours, experiences: exps)

            try await FirestoreService.shared.updateTripPlan(
                tripPlanId: tripPlanId,
                fields: [
                    "recommendedTourIds": rec.tourIds,
                    "recommendedExperienceIds": rec.experienceIds
                ]
            )
        } catch {
            // Non-fatal; the plan still exists.
            print("Failed to link in-app recommendations: \(error)")
        }
    }
}

/// Wraps a view in a NavigationStack with a close button for fullScreenCover presentations.
private struct DismissableSheet<Content: View>: View {
    @Environment(\.dismiss) private var dismiss
    let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        NavigationStack {
            content
        }
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "xmark")
                }
            }
        }
    }
}

private struct TripPlanResultsView: View {
    let plan: [String: Any]

    var body: some View {
        LuxuryCard {
            VStack(alignment: .leading, spacing: 10) {
                Text(plan["title"] as? String ?? "Your plan")
                    .font(.title3.bold())
                    .foregroundStyle(.white)

                if let summary = plan["summary"] as? String {
                    Text(summary)
                        .foregroundStyle(.white.opacity(0.8))
                }

                if let days = plan["days"] as? [[String: Any]] {
                    ForEach(Array(days.enumerated()), id: \.offset) { _, day in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(day["dateISO"] as? String ?? "")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(Lx.gold)

                            if let theme = day["theme"] as? String {
                                Text(theme)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }

                            if let items = day["items"] as? [[String: Any]] {
                                ForEach(Array(items.enumerated()), id: \.offset) { _, item in
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("\((item["time"] as? String) ?? "") • \((item["title"] as? String) ?? "")")
                                            .font(.subheadline.weight(.semibold))
                                            .foregroundStyle(.white)
                                        Text(item["description"] as? String ?? "")
                                            .font(.caption)
                                            .foregroundStyle(.white.opacity(0.75))
                                    }
                                    .padding(.vertical, 4)
                                }
                            }
                        }
                        Divider().opacity(0.12)
                    }
                }

                if let notes = plan["budgetNotes"] as? String, !notes.isEmpty {
                    Text(notes)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.75))
                }
            }
        }
    }
}

// MARK: - Destination picker (searchable)

private struct Destination: Identifiable, Hashable {
    let id = UUID()
    let city: String
    let country: String

    var label: String { "\(city), \(country)" }
}

/// Searchable picker for (city, country) pairs.
/// Keeps the input controlled to known destinations to help the AI create better plans.
private struct DestinationPickerView: View {
    @Environment(\.dismiss) private var dismiss

    @Binding var selectedCity: String
    @Binding var selectedCountry: String

    @State private var query = ""

    // A curated list of popular destinations. You can extend this list anytime
    // (or later replace it with a remote dataset).
    private let destinations: [Destination] = [
        Destination(city: "Bucharest", country: "Romania"),
        Destination(city: "Cluj-Napoca", country: "Romania"),
        Destination(city: "Brasov", country: "Romania"),
        Destination(city: "Iasi", country: "Romania"),
        Destination(city: "Timisoara", country: "Romania"),
        Destination(city: "Sibiu", country: "Romania"),
        Destination(city: "Constanta", country: "Romania"),
        Destination(city: "Vienna", country: "Austria"),
        Destination(city: "Prague", country: "Czech Republic"),
        Destination(city: "Budapest", country: "Hungary"),
        Destination(city: "Paris", country: "France"),
        Destination(city: "Nice", country: "France"),
        Destination(city: "Rome", country: "Italy"),
        Destination(city: "Milan", country: "Italy"),
        Destination(city: "Barcelona", country: "Spain"),
        Destination(city: "Madrid", country: "Spain"),
        Destination(city: "London", country: "United Kingdom"),
        Destination(city: "Edinburgh", country: "United Kingdom"),
        Destination(city: "Amsterdam", country: "Netherlands"),
        Destination(city: "Berlin", country: "Germany"),
        Destination(city: "Munich", country: "Germany"),
        Destination(city: "Zurich", country: "Switzerland"),
        Destination(city: "Athens", country: "Greece"),
        Destination(city: "Santorini", country: "Greece"),
        Destination(city: "Istanbul", country: "Turkey"),
        Destination(city: "Dubai", country: "United Arab Emirates"),
        Destination(city: "New York", country: "United States"),
        Destination(city: "Los Angeles", country: "United States"),
        Destination(city: "Miami", country: "United States"),
        Destination(city: "Tokyo", country: "Japan"),
        Destination(city: "Kyoto", country: "Japan"),
        Destination(city: "Seoul", country: "South Korea"),
        Destination(city: "Bangkok", country: "Thailand"),
        Destination(city: "Singapore", country: "Singapore")
    ]

    private var filtered: [Destination] {
        let q = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !q.isEmpty else { return destinations }
        return destinations.filter {
            $0.city.localizedCaseInsensitiveContains(q)
            || $0.country.localizedCaseInsensitiveContains(q)
            || $0.label.localizedCaseInsensitiveContains(q)
        }
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(filtered) { d in
                    Button {
                        selectedCity = d.city
                        selectedCountry = d.country
                        dismiss()
                    } label: {
                        VStack(alignment: .leading, spacing: 2) {
                            Text(d.city).font(.headline)
                            Text(d.country).font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Destination")
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always), prompt: "Search city or country")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }
}
// MARK: - Utilities

private extension Date {
    var isoDateOnlyString: String {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .iso8601)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: self)
    }
}

