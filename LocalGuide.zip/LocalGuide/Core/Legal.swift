import Foundation

enum Legal {
    static let termsVersion: Int = 1
    static let intermediaryVersion: Int = 1
    static let privacyVersion: Int = 1
    static let cancellationPolicyVersion: Int = 1
}
