# Bundle ID
Set your Xcode target **Bundle Identifier** to:
- `localguide`

This is configured in Xcode (Signing & Capabilities), not in Swift code.
