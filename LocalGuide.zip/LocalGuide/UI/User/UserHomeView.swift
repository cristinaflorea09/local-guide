import SwiftUI

struct UserHomeView: View {
    @EnvironmentObject var chatUnread: ChatUnreadService

    private enum Tab: Hashable {
        case home, explore, plan, bookings, chat, more
    }

    @State private var selection: Tab = .home
    @State private var morePath = NavigationPath()

    var body: some View {
        TabView(selection: $selection) {
            NavigationStack {
                UserDashboardView()
            }
            .tabItem { Label("Home", systemImage: "house") }
            .tag(Tab.home)

            NavigationStack {
                ExploreMarketplaceView()
            }
            .tabItem { Label("Tours/Experiences", systemImage: "magnifyingglass") }
            .tag(Tab.explore)

            NavigationStack {
                TripPlannerView()
            }
            .tabItem { Label("Plan", systemImage: "sparkles") }
            .tag(Tab.plan)

            NavigationStack {
                UserBookingsView()
            }
            .tabItem { Label("Bookings", systemImage: "ticket") }
            .tag(Tab.bookings)

            NavigationStack {
                ChatsListView(mode: .traveler)
            }
            .tabItem { Label("Chat", systemImage: "message") }
            .badge(chatUnread.unreadCount == 0 ? 0 : chatUnread.unreadCount)
            .tag(Tab.chat)

            NavigationStack(path: $morePath) {
                List {
                    Section {
                        NavigationLink("Map", value: "map")
                        NavigationLink("Community", value: "community")
                        NavigationLink("Premium", value: "premium")
                    }
                    Section {
                        NavigationLink("Account", value: "account")
                        NavigationLink("Settings", value: "settings")
                    }
                }
                .navigationTitle("More")
                .navigationDestination(for: String.self) { key in
                    switch key {
                    case "map": GoogleMapToursView()
                    case "community": CommunityFeedView()
                    case "premium": SubscriptionView()
                    case "account": AccountView()
                    default: SettingsView()
                    }
                }
            }
            .tabItem { Label("More", systemImage: "ellipsis.circle") }
            .tag(Tab.more)
        }
        // Ensure "More" starts fresh every time you tap it.
        .onChange(of: selection) { oldValue, newValue in
            if newValue == .more {
                morePath = NavigationPath()
            }
        }
    }
}

