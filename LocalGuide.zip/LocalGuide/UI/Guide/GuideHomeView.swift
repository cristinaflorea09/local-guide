import SwiftUI

struct GuideHomeView: View {
    @EnvironmentObject var appState: AppState
    @EnvironmentObject var chatUnread: ChatUnreadService

    private enum Tab: Hashable {
        case home, tours, availability, chat, more
    }

    @State private var selection: Tab = .home
    @State private var morePath = NavigationPath()

    private var isApproved: Bool {
        (appState.session.currentUser?.guideApproved ?? false) == true
    }

    var body: some View {
        TabView(selection: $selection) {
            NavigationStack {
                GuideGateView()
            }
            .tabItem { Label("Home", systemImage: "house") }
            .tag(Tab.home)

            NavigationStack {
                if isApproved { GuideToursView() }
                else { NotApprovedView() }
            }
            .tabItem { Label("Tours", systemImage: "map") }
            .tag(Tab.tours)

            NavigationStack {
                if isApproved { GuideAvailabilityView() }
                else { NotApprovedView() }
            }
            .tabItem { Label("Availability", systemImage: "calendar.badge.plus") }
            .tag(Tab.availability)

            NavigationStack {
                if isApproved { ChatsListView(mode: .seller) }
                else { NotApprovedView() }
            }
            .tabItem { Label("Chat", systemImage: "message") }
            .badge(chatUnread.unreadCount == 0 ? 0 : chatUnread.unreadCount)
            .tag(Tab.chat)

            NavigationStack(path: $morePath) {
                List {
                    Section {
                        if isApproved {
                            NavigationLink("Campaigns", value: "campaigns")
                            NavigationLink("Bookings", value: "bookings")
                            NavigationLink("Earnings", value: "earnings")
                            NavigationLink("Profile", value: "profile")
                        }
                    }
                    Section {
                        NavigationLink("Community", value: "community")
                        NavigationLink("Account", value: "account")
                        NavigationLink("Settings", value: "settings")
                    }
                }
                .navigationTitle("More")
                .navigationDestination(for: String.self) { key in
                    switch key {
                    case "campaigns": SellerCampaignsView()
                    case "bookings": GuideBookingsView()
                    case "earnings": SellerEarningsDashboardView()
                    case "profile": GuideProfileEditView()
                    case "community": CommunityFeedView()
                    case "account": AccountView()
                    default: SettingsView()
                    }
                }
            }
            .tabItem { Label("More", systemImage: "ellipsis.circle") }
            .tag(Tab.more)
        }
        .onChange(of: selection) { newTab in
            if newTab == .more { morePath = NavigationPath() }
        }
    }
}

private struct NotApprovedView: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 12) {
                Image(systemName: "lock.fill")
                    .font(.title2)
                    .foregroundStyle(Lx.gold)
                Text("Pending approval")
                    .font(.title3.bold())
                    .foregroundStyle(.white)
                Text("This section will unlock once your guide account is approved.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.white.opacity(0.7))
                    .padding(.horizontal, 22)
            }
        }
    }
}
