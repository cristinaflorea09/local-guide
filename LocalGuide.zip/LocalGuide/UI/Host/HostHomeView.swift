import SwiftUI

struct HostHomeView: View {
    @EnvironmentObject var appState: AppState
    @EnvironmentObject var chatUnread: ChatUnreadService

    private enum Tab: Hashable {
        case home, experiences, bookings, chat, more
    }

    @State private var selection: Tab = .home
    @State private var morePath = NavigationPath()

    private var isApproved: Bool {
        (appState.session.currentUser?.hostApproved ?? false) == true
    }

    var body: some View {
        TabView(selection: $selection) {
            NavigationStack {
                HostGateView()
            }
            .tabItem { Label("Home", systemImage: "house") }
            .tag(Tab.home)

            NavigationStack {
                HostExperiencesView()
            }
            .tabItem { Label("Experiences", systemImage: "sparkles") }
            .tag(Tab.experiences)

            NavigationStack {
                HostBookingsView()
            }
            .tabItem { Label("Bookings", systemImage: "calendar") }
            .tag(Tab.bookings)

            NavigationStack {
                ChatsListView(mode: .seller)
            }
            .tabItem { Label("Chat", systemImage: "message.fill") }
            .badge(chatUnread.unreadCount == 0 ? 0 : chatUnread.unreadCount)
            .tag(Tab.chat)

            NavigationStack(path: $morePath) {
                List {
                    Section {
                        if isApproved {
                            NavigationLink("Create Experience", value: "create")
                            NavigationLink("Campaigns", value: "campaigns")
                            NavigationLink("Availability", value: "availability")
                            NavigationLink("Earnings", value: "earnings")
                        }
                    }
                    Section {
                        NavigationLink("Community", value: "community")
                        NavigationLink("Account", value: "account")
                        NavigationLink("Settings", value: "settings")
                    }
                }
                .navigationTitle("More")
                .navigationDestination(for: String.self) { key in
                    switch key {
                    case "create": CreateExperienceView()
                    case "campaigns": SellerCampaignsView()
                    case "availability": GuideAvailabilityView()
                    case "earnings": SellerEarningsDashboardView()
                    case "community": CommunityFeedView()
                    case "account": AccountView()
                    default: SettingsView()
                    }
                }
            }
            .tabItem { Label("More", systemImage: "ellipsis.circle") }
            .tag(Tab.more)
        }
        .onChange(of: selection) { oldValue, newValue in
            if newValue == .more { morePath = NavigationPath() }
        }
    }
}

