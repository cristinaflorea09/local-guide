# Romania assumptions (starter)

Used by `EarningsSimulatorRomaniaView`.

- Bucharest: higher demand, higher pricing
- Cluj-Napoca: strong weekend tourism + business travel
- Brașov: seasonal peaks + group experiences
- Timișoara: steady local demand

Adjust averages and booking rates as you collect real marketplace data.
